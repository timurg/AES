﻿using Microsoft.AspNetCore.Identity;

namespace WebStory.Models;

public class ApplicationUser : IdentityUser
{
}